# Bangkit Proyek Analisis Data

## Setup environment
```
pip install virtualenv
python -m venv env
.\env\Scripts\activate
pip install -r .\requirements.txt
```

## Run steamlit app
```
streamlit run dashboard.py
```

